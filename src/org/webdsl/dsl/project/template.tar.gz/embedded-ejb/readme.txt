This directory contains a JBoss Embeddable EJB 3.0 configuration. 

The embedded-ejb/conf directory must be included in the classpath 
to run the Embeddable EJB container.